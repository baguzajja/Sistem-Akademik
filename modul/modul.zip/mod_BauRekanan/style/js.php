<?php 
defined('_FINDEX_') or die('Access Denied');
$mod=$_REQUEST['page'];
$act=(isset($_REQUEST['act']))? $_REQUEST['act']:null;
addJs(AdminPath.'/js/plugins/lightbox/jquery.lightbox.js');
switch($act)
{
}
	
?>